
import {createStore, combineReducers} from 'redux';
import { UserReducers } from './Reducers/UserReducers';

const rootReducer = combineReducers({
    UserReducers
})

export const store = createStore(rootReducer);