export const SET_USER_LOGIN  = "SET_USER_LOGIN"
export const GET_USER = "GET_USER"

export const USER_LOGOUT = "USER_LOGOUT"